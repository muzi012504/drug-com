package com.javaclimb.drug.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.drug.entity.Returnsupplier;

/**
 * 退货给供应商的增删改查Mapper
 */
public interface ReturnsupplierMapper extends BaseMapper<Returnsupplier> {
}
